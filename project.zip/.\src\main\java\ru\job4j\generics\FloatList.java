package ru.job4j.generics;

import java.util.ArrayList;

public class FloatList extends ArrayList<Float> {

}